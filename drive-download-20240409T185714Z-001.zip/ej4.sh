#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 07/04/2004
# Descripción: Este script realiza un listado del directorio actual con un separador de campos de ':'.
clear

##Parámetros/Variables
archivo_salida="$1"

##Funciones


##Bloque principal

# Verificar si se proporcionó un argumento para el archivo de salida
if [ $# -ne 1 ]; then
    echo "Uso: $0 <archivo_de_salida>"
    exit 
fi

# Verificar si el directorio actual es accesible
if [ ! -d "$PWD" ]; then
    echo "El directorio actual no es accesible."
    exit 
fi

# Obtener el listado del directorio actual ordenado por nombre de archivo con separador de campos de dos puntos (:)

ls -p -1 | grep -v / | sort | paste -sd ':' > "$archivo_salida"
echo "Listado de archivos del directorio actual ordenados por nombre y guardados en $archivo_salida"
echo ""
echo "     LISTADO       "
echo "-------------------"
cat $archivo_salida


