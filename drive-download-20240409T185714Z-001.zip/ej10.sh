#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 07/04/2024
# Descripción: Este script realiza una operación aritmética.
 clear

# Introducir un valor numérico
read -p  "Introduzca un valor numérico: " x

# Calcular el resultado de la fórmula
resultado=$(echo "scale = 2; 3"$x"2 + 5"$x" + 8" | bc)


# Mostrar el resultado
echo ""
echo "El resultado de la operación 3"$x"2 + 5"$x" + 8 es: $resultado"
