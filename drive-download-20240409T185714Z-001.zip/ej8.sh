#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 07/04/2024
# Descripción: Este script muestra información del usuario activo.
clear
nombreUsuario=$(whoami)
	echo ""
	echo "  Información del usuario activo"
	echo "-------------------------------------"
	
# Mostrar el nombre de usuario
	echo "Nombre de usuario: $nombreUsuario"

# Obtener el directorio de trabajo del usuario
	directorio_trabajo=$(grep "^$nombreUsuario:" /etc/passwd | cut -d ':' -f 6)
	echo "Directorio de trabajo: $directorio_trabajo"

# Obtener la shell asociada al usuario
	shell_usuario=$(grep "^$nombreUsuario:" /etc/passwd | cut -d ':' -f 7)
	echo "Shell asociada al usuario: $shell_usuario"

