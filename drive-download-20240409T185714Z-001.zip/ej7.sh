#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 07/04/2024
# Descripción: Este script realiza SALUDO.
clear
saludo() {
  hora_actual=$(date +%H)

  if [ $hora_actual -ge 6 ] && [ $hora_actual -lt 12 ]; then
    echo "¡BUENOS DÍAS!" 
  elif [ $hora_actual -ge 12 ] && [ $hora_actual -lt 20 ]; then
    echo "¡BUENAS TARDES!"
  else
    echo "¡BUENAS NOCHES!"
  fi
}
echo ""
echo ""
# Llamada a la función
saludo
echo ""
echo ""

