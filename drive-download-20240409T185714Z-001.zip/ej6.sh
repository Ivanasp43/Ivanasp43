#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 07/04/2024
# Descripción: Este script realiza la lectura de la pulsación de una tecla.
clear

##Bloque principal
while true; do
    echo ""
    read -p "Presiona una tecla o Enter para salir: " tecla
    

    # Salir si se presiona Enter
    if [ "$tecla" = "" ]; then
        echo "Saliendo..."
        exit
    fi 

    # Verificar si la tecla pulsada es un número
    if [ "$tecla" -ge 0 ] 2>/dev/null && [ "$tecla" -le 9 ] 2>/dev/null; then
        echo "La tecla pulsada es un número: $tecla"
    
    # Verificar si la tecla pulsada es una letra
    elif echo "$tecla" | grep -q '[[:alpha:]]'; then
        echo "La tecla pulsada es una letra: $tecla"
    else
        echo "La tecla pulsada no es ni un número ni una letra: $tecla"
    fi
 
done
