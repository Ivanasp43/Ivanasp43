#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 07/04/2024
# Descripción: Este script modifica, muestra y guarda el contenido de un fichero según se pide en el ejercicio (4 ficheros: Todo minúscula, todo mayúscula, sin letra "a" y todas las vocales mayúsculas).
clear

	if [ $# -ne 1 ]; then
   		echo "Uso: $0 <nombre_del_fichero>"
    		exit 
	fi

fichero="$1"

# Verificar si el archivo existe
	if [ ! -f "$fichero" ]; then
    		echo "El archivo $fichero no existe."
    		exit 
	fi

# Verificar si el archivo está vacío
	if [ ! -s "$fichero" ]; then
    		echo "El archivo $fichero está vacío."
    		exit 
	fi

# Mostrar contenido original en pantalla y en fichero
echo "Contenido original del fichero $fichero:"
echo "-----------------------------------------"
cat "$fichero"
echo "------------------------------------"
echo "Contenido del fichero en minúsculas"
echo "------------------------------------"
cat "$fichero" | tr '[:upper:]' '[:lower:]' | tee R_minusculas.txt
echo "------------------------------------"
echo "Contenido del fichero en mayúsculas"
echo "------------------------------------"
cat "$fichero" | tr '[:lower:]' '[:upper:]' | tee R_mayusculas.txt
echo "---------------------------------------------------"
echo "Contenido eliminando las ocurrencias de la letra a"
echo "---------------------------------------------------"
cat "$fichero" | tr -d 'a' | tee R_sinA.txt
echo "----------------------------------------------"
echo "Contenido con todas las vocales en mayúsculas"
echo "----------------------------------------------"
cat "$fichero" | tr 'aeiou' 'AEIOU' | tee R_VOCALES.txt
echo ""
echo "Transformaciones completadas. Archivos generados: R_minusculas.txt, R_mayusculas.txt, R_sinA.txt, R_VOCALES.txt"
