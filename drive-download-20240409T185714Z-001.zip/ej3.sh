#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 08/04/2024
# Descripción: Este script realiza dieferencia entre ficheros.
##Parámetros/Variables
archivo1=$1
archivo2=$2
ficheroSalida=$3
##Funciones
mostrarAyuda() {
  echo ""
  echo "Número de argumentos incorrecto."
  echo "Uso: $0 <fichero> <fichero> <fichero de salida>"
  echo "<fichero>: Ruta al archivo que se desea leer."
  echo ""
  exit 1
}

comprobarArgumentos()
{
	if [ "$#" -ne "3" ]; then
        mostrarAyuda
	fi
}

comprobarFicheros()
{
	if [ ! -f "$1" ] || [ ! -s "$1" ]; then
    		echo "El fichero $1 no existe o está vacío ."
   		exit 
	fi
	if [ ! -f "$2" ] || [ ! -s "$2" ]; then
    		echo "El fichero $2 no existe o está vacío ."
   		exit 
   	fi
}

diferencias() 
{
	echo ""
	diff  "$1" "$2" | tail -n +2 | nl | tee "$3"
}


##Bloque principal
clear
comprobarArgumentos "$@"
comprobarFicheros "$1" "$2" "$3"
diferencias "$1" "$2" "$3"
