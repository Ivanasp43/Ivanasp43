#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 05/04/2024
# Descripción: Este script realiza cuenta de A hasta B.
clear
##Parámetros/Variables
##Funciones
##Bloque principal

#Introducir los números enteros.
while true; do
	read -p "Inserta variable A: " A
	read -p "Inserta variable B: " B
	
	if ! [[ "$A" =~ ^[0-9]+$ ]] || ! [[ "$B" =~ ^[0-9]+$ ]]; then
        	echo "Error: A y B deben ser números enteros. Vuelva a introducir los valores."
       		echo ""
        	continue
        fi
 #El valor de A tiene que ser menor que el de B.     
	if [ "$A" -ge "$B" ]; then
		echo "Error: A debe ser menor que B.Vuelva a introducir los valores."
		echo ""
		continue		
	fi 
#Dar a A el valor 99, salir del sistema.	
	if [ "$A" = "99" ]; then 
		echo ""
		echo "El valor de A es 99. Saliendo del sistema..."
		exit
	fi
		echo ""
		echo "El resultado sería el siguiente: "
		echo ""
#Realizar la cuenta y mostrar el resultado.Cuando A llega a 99 salir del sistema.
	until [ $A = $(($B+1)) ];do
    		echo "$A / $B"
    	
    		$((A=A+1)) >> /dev/null 2>&1  
    	
    	if [ "$A" -eq "99" ]; then
        	echo "$A / $B"
        	echo ""
        	echo "El valor de A acanzó el 99. Saliendo del sistema..."
        	echo ""
        exit 0
    	fi
	done
	echo ""
	break
done
	

