#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 
# Descripción: Este script muestra el contenido numerado de un archivo proporcionado como argumento y te dice el total de líneas, palabras y carácteres del archivo.
clear
##Parámetros/Variables
##Funciones

# Validar número de argumentos
comprobarArgumentos()
{
    if [ $1 -eq 0 ]; then
    	echo ""
    	echo "No has inidcado ningún archivo en la ejecución del script."
    	echo ""
    	exit
    elif [ $1 -ne 1 ];
    then
    	echo "Has introucido más de un parámetro."
    	exit
    fi  
    
}

comprobarFichero()
{
    if [ ! -f $1 ]; then
    	echo ""
        echo "El fichero $1 no existe"
        echo ""
        exit
    fi

}
##Bloque principal
comprobarArgumentos $#
comprobarFichero $1

# Mostrar contenido del archivo con líneas numeradas
lineas=1
	while read linea; do
  		echo "$lineas: $linea"
  		lineas=$(($lineas+1))
	done < $1

# Obtener número de líneas, palabras y caracteres
numero_lineas=$(wc -l "$1" | awk '{print $1}')
numero_palabras=$(wc -w "$1" | awk '{print $1}')
numero_caracteres=$(wc -c "$1" | awk '{print $1}')

# Mostrar información final
echo ""
echo "Total de líneas: $numero_lineas"
echo "Total de palabras: $numero_palabras"
echo "Total de caracteres: $numero_caracteres"

