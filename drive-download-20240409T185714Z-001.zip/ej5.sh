#!/bin/bash
# Authors: David R. , Ivana S. , Andrés R.
# Versión: 1.0
# Fecha: 07/04/2024
# Descripción: Este script recibe como argumento un directorio e introduce en un array todos los ficheros que contiene el directorio introducido como argumento. Tras esto pide que seleccione una de las opciones entre los números mostrados y te muestra información del archivo que almacena la posición del array.
clear

##Parámetros/Variables
directorio="$1"

##Funciones
mostrarAyuda() {
  echo ""
  echo "Número de argumentos incorrecto."
  echo "Uso: $0 <directorio>"
  echo "<directorio>: Ruta al directorio que se desea leer."
  echo ""
  exit 1
}

obtenerInfoArchivo() {
  archivo="$1"
  numeroCaracteres=$(wc -c < "$archivo") >> /dev/null 2>&1
  echo "Nombre del archivo: $archivo"
  echo "Número de caracteres: $numeroCaracteres"
  echo ""
}

##Bloque principal

# Validar que se ha introducido un solo parámetro
if [ $# -gt 1 ]; then
  echo "Error: Debe introducir 1 solo argumento."
  echo ""
  mostrarAyuda
  exit 1
elif [ $# -lt 1 ]; then
  echo "Error: Debe introducir 1 argumento."
  echo ""
  mostrarAyuda
  exit 1
fi
# Validar que se ha introducido un directorio útil como parámetro
if [ ! -s "$directorio" ]; then
  echo "El directorio $directorio no existe."
  echo ""
  exit 1
elif [ -f "$directorio" ]; then
  echo "El argumento indicado no es un directorio."
  echo ""
  exit 1
fi

# Obtener la lista de archivos en el directorio
archivos=($(ls -1 "$directorio"))

# Validar que el directorio no está vacío
if [ ${#archivos[@]} -eq 0 ]; then
  echo "El directorio '$directorio' está vacío."
  echo ""
  exit 1
fi

# Bucle para solicitar un número y mostrar la información del archivo
until  [ "$numero" = "0" ]; do
  # Pedir un número
  read -p "Introduzca un número entre 1 y ${#archivos[@]} (0 para salir): " numero

  # Validar el número introducido
  if [[ ! $numero =~ ^[0-9]+$ ]]; then # Si el número almacenado en la variable $numero no coincide con un número que empiece entre el 0 y el 9, entonces...
    echo "Error: Debe introducir un número entero."
    echo ""
    continue
  elif [ $numero -gt ${#archivos[@]} ]; then # Si el número almacenado en la variable $numero es mayor que el número de nombres almacenados en el array 'archivos', entonces...
    echo "Error: El número introducido está fuera del rango."
    echo ""
    continue
  elif [ $numero -eq 0 ]; then
    echo "Saliendo del programa..."
    echo ""
    exit 0
  fi

  # Obtener el nombre del archivo
  archivo="${archivos[$numero - 1]}"

  # Mostrar la información del archivo
  obtenerInfoArchivo "$archivo"
done
